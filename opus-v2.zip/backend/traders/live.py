"""Live trader for Binance USDT-M Futures.

This is the first live-capable implementation: market-taker entries, guarded
per-symbol live state, Binance private-WS health gate, leverage setup, and
emergency flatten for managed symbols.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any

from backend.config import settings
from backend.exchanges.binance_rest import BinanceRest, get_client
from backend.log import get_logger
from backend.safety.guards import OrderIntent, check, record_order_sent
from backend.settings_store import RuntimeSettings
from backend.state import AppState
from backend.traders.base import Trader

if TYPE_CHECKING:
    from backend.ml.inference import Predictor

log = get_logger(__name__)


class LiveTrader(Trader):
    """Market-taker live trader with strict pre-trade gates."""

    def __init__(
        self,
        state: AppState,
        *,
        predictor: Predictor | None = None,
        rest_client: BinanceRest | None = None,
        runtime_settings: RuntimeSettings | None = None,
    ) -> None:
        self.state = state
        self.predictor = predictor
        self.rest = rest_client or get_client()
        self.runtime_settings = runtime_settings or RuntimeSettings()
        self._running = False
        self._leveraged_symbols: set[str] = set()
        self._open_symbols: set[str] = set()

    async def start(self) -> None:
        self._running = True
        log.warning("LIVE trader: started; real Binance orders are enabled for per-symbol live rows")

    async def stop(self) -> None:
        self._running = False
        log.info("live trader: stopping, cancelling and flattening managed symbols")
        await self.emergency_flatten()

    async def on_book_update(self, symbol: str) -> None:
        return

    async def cancel_all(self, symbol: str) -> None:
        try:
            await self.rest.cancel_all(symbol.upper())
        except Exception as e:
            log.warning("cancel_all(%s) failed: %s", symbol, e)

    async def flatten_symbol(self, symbol: str) -> None:
        """Cancel open orders and close any live Binance position for one symbol."""

        symbol = symbol.upper()
        await self.cancel_all(symbol)
        await self._flatten(symbol)

    async def emergency_flatten(self) -> None:
        """Best-effort flatten for every symbol managed by this trader."""

        for sym in self._managed_symbols():
            await self.flatten_symbol(sym)

    async def on_snapshot(self, symbol: str, snap: dict[str, Any]) -> None:
        """Evaluate a live entry on the latest snapshot."""

        if not self._running:
            return
        symbol = symbol.upper()
        stats = self.state.symbols.get(symbol)
        if stats is None:
            return
        if stats.execution_mode != "live" or stats.live_state not in {"probation_live", "active_live"}:
            return
        if symbol in self._open_symbols:
            return

        if not self._private_ws_ready():
            self._reject_symbol(symbol, "private ws not ready")
            return
        if self.predictor is None or not getattr(self.predictor, "enabled", False):
            self._reject_symbol(symbol, "predictor disabled")
            return

        pred = self._prediction(symbol, snap)
        if pred is None:
            return
        expected_gross_bp = self._expected_gross_bp(symbol, pred)
        stats.expected_gross_bp = expected_gross_bp
        if expected_gross_bp < self.runtime_settings.min_expected_gross_bp:
            stats.block_reason = (
                f"expected gross {expected_gross_bp:.2f}bp < "
                f"{self.runtime_settings.min_expected_gross_bp:.2f}bp"
            )
            return
        if abs(float(pred.confidence)) < settings.trade_conf_threshold:
            return

        side = "BUY" if pred.confidence > 0 else "SELL"
        entry_price = float(snap.get("best_ask" if side == "BUY" else "best_bid", 0.0))
        if entry_price <= 0:
            self._reject_symbol(symbol, "invalid entry price")
            return

        notional = float(stats.current_notional_usd or self.runtime_settings.probation_notional_usd)
        qty = notional / entry_price
        intent = OrderIntent(
            symbol=symbol,
            side=side,
            qty=qty,
            price=entry_price,
            notional_usd=notional,
        )
        reason = check(self.state, intent, "live")
        if reason is not None:
            self._reject_symbol(symbol, reason)
            return

        await self._ensure_leverage(symbol)
        client_order_id = f"OPUS_{symbol}_{int(time.time() * 1000)}_{side}"
        try:
            await self.rest.place_order(
                symbol=symbol,
                side=side,
                order_type="MARKET",
                quantity=qty,
                reduce_only=False,
                client_order_id=client_order_id,
            )
        except Exception as e:
            self._reject_symbol(symbol, f"order failed: {e}")
            return

        self._open_symbols.add(symbol)
        record_order_sent(self.state.guards)
        stats.position_base = qty if side == "BUY" else -qty
        stats.position_entry = entry_price
        stats.fills_count += 1
        log.info("live: OPEN %s %s qty=%.8f notional=$%.2f", side, symbol, qty, notional)

    def _prediction(self, symbol: str, snap: dict[str, Any]):
        try:
            preds = self.predictor.predict(symbol, snap) if self.predictor is not None else None
        except Exception as e:
            self._reject_symbol(symbol, f"predict failed: {e}")
            return None
        if not preds:
            return None
        pred = preds.get(settings.trade_horizon)
        if pred is None and len(preds) == 1:
            return next(iter(preds.values()))
        return pred

    def _expected_gross_bp(self, symbol: str, pred: Any) -> float:
        latest_derived = getattr(self.predictor, "latest_derived", None)
        if latest_derived is None:
            return self.runtime_settings.min_expected_gross_bp
        derived = latest_derived(symbol)
        vol_bp = float(derived.get("vol_w120_bp") or 0.0)
        if not vol_bp > 0.0:
            return 0.0
        return abs(float(pred.confidence)) * vol_bp

    async def _ensure_leverage(self, symbol: str) -> None:
        if symbol in self._leveraged_symbols:
            return
        await self.rest.set_leverage(symbol, self.runtime_settings.leverage)
        self._leveraged_symbols.add(symbol)

    async def _flatten(self, symbol: str) -> None:
        try:
            position_amt = await self.rest.get_open_position_amt(symbol)
            if position_amt:
                await self.rest.market_close_position(symbol, position_amt)
            stats = self.state.symbols.get(symbol)
            if stats is not None:
                stats.position_base = 0.0
                stats.position_entry = 0.0
                stats.unrealized_pnl = 0.0
            self._open_symbols.discard(symbol)
        except Exception as e:
            log.warning("flatten(%s) failed: %s", symbol, e)

    def _managed_symbols(self) -> list[str]:
        return [
            sym
            for sym, stats in self.state.symbols.items()
            if stats.execution_mode == "live"
            and stats.live_state in {"probation_live", "active_live", "cooldown", "disabled"}
        ]

    def _private_ws_ready(self) -> bool:
        if not self.state.binance_private_connected:
            return False
        if self.state.binance_private_last_msg_ts <= 0:
            return False
        age_ms = (time.time() - self.state.binance_private_last_msg_ts) * 1000.0
        return age_ms <= self.state.guards.ws_stale_ms

    def _reject_symbol(self, symbol: str, reason: str) -> None:
        stats = self.state.symbols.get(symbol)
        if stats is not None:
            stats.rejects_count += 1
            stats.block_reason = reason
        log.debug("live: reject %s: %s", symbol, reason)
